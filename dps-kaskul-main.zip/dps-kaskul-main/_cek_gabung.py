import sys
sys.path.insert(0, r"c:\Users\irgir\Downloads\dps-kaskul-main\dps-kaskul-main")
import convert as c
from collections import defaultdict, Counter

mentah = c.baca_xlsx(r"c:\Users\irgir\Downloads\dps-kaskul-main\DAFTAR PEMILIH SEMENTARA (2).xlsx")
print("baris:", len(mentah), "| utama:", sum(1 for r in mentah if not r["tambahan"]),
      "| tambahan:", sum(1 for r in mentah if r["tambahan"]))

kelompok = defaultdict(list)
for r in mentah:
    kelompok[c.kunci(r)].append(r)

hasil, dobel = [], []
for grup in kelompok.values():
    if len(grup) == 1:
        hasil.append(grup)
        continue
    kantong = []
    for r in sorted(grup, key=c.mutu):
        for wakil, isi in kantong:
            if c.nama_serupa(wakil, r["nama"]):
                isi.append(r)
                break
        else:
            kantong.append((r["nama"], [r]))
    hasil.extend(isi for _w, isi in kantong)
    if len(kantong) > 1:
        dobel.append(kantong)

rows = [sorted(g, key=c.mutu)[0] for g in hasil]
print("unik:", len(rows), "| dibuang:", len(mentah) - len(rows), "| NIK dobel antar orang:", len(dobel))

print("\n== NIK dobel (sekarang DIPISAH, tampil 2 orang) ==")
for kantong in dobel:
    print("  " + " || ".join(f"{i[0]['nama']} (RT{i[0]['rt']}/RW{i[0]['rw']})" for _w, i in kantong))

print("\n== contoh pasangan yang DIGABUNG karena nama mirip ==")
n = 0
for grup in kelompok.values():
    nama = {r["nama"] for r in grup}
    if len(nama) > 1 and not any(len(k[0]["nama"]) or True for k in []):
        pass
gabung = []
for grup in kelompok.values():
    nama = sorted({r["nama"] for r in grup})
    if len(nama) > 1:
        for i in range(len(nama)):
            for j in range(i + 1, len(nama)):
                if c.nama_serupa(nama[i], nama[j]):
                    gabung.append((nama[i], nama[j]))
for a, b in gabung[:20]:
    print(f"  {a}  ~  {b}")
print("  total pasangan digabung:", len(gabung))

print("\nunik per RW:", dict(sorted(Counter(r["rw"] for r in rows).items())))
print("utama unik:", len({c.kunci(r) for r in mentah if not r['tambahan']}),
      "| unik dari semua:", len(rows))
utama_set = {x for r in mentah if not r["tambahan"] for x in [c.kunci(r)]}
print("pemilih baru dari TAMBAHAN:",
      sum(1 for r in rows if r["tambahan"]), "(baris tambahan yang jadi wakil grup)")
