import openpyxl, re, collections, difflib

SRC = "DAFTAR PEMILIH SEMENTARA (2).xlsx"
wb = openpyxl.load_workbook(SRC, read_only=True, data_only=True)


def teks(x):
    return re.sub(r"\s+", " ", str(x if x is not None else "").strip()).upper()


def angka(x):
    return re.sub(r"\D", "", str(x if x is not None else ""))


def bersih(n):
    return re.sub(r"[^A-Z0-9 ]", "", n).replace("  ", " ").strip()


rows = []
for ws in wb.worksheets:
    hdr = None
    for i, r in enumerate(ws.iter_rows(values_only=True), start=1):
        sel = [teks(c) for c in r]
        if "NAMA" in sel and "NIK" in sel:
            hdr = {k: j for j, k in enumerate(sel) if k}
            break
    if not hdr:
        continue
    for r in ws.iter_rows(min_row=i + 1, values_only=True):
        g = lambda k: r[hdr[k]] if k in hdr and hdr[k] < len(r) else None
        nama = teks(g("NAMA"))
        if not nama or nama == "NAMA" or nama.isdigit():
            continue
        rows.append(dict(nama=nama, nik=angka(g("NIK")), jk=teks(g("JENIS KELAMIN")),
                         rt=angka(g("RT")), rw=angka(g("RW")), sheet=ws.title))
wb.close()

grup = collections.defaultdict(list)
for r in rows:
    if len(r["nik"]) == 16:
        grup[r["nik"]].append(r)

print("== grup NIK ganda dengan nama berbeda ==")
beda = []
for nik, v in grup.items():
    nama = sorted({bersih(x["nama"]) for x in v})
    if len(nama) < 2:
        continue
    # ratio terhadap nama pertama yang berbeda
    rasio_maks = 0
    for i in range(len(nama)):
        for j in range(i + 1, len(nama)):
            rasio_maks = max(rasio_maks, difflib.SequenceMatcher(None, nama[i], nama[j]).ratio())
    prefiks = any(a.startswith(b) or b.startswith(a) for a in nama for b in nama if a != b)
    beda.append((rasio_maks, prefiks, nik, v))

beda.sort(reverse=True)
for rasio, prefiks, nik, v in beda:
    jk = {x["jk"] for x in v}
    print(f"  {rasio:.2f} prefix={int(prefiks)} jk={'/'.join(sorted(jk))}  " +
          " || ".join(f"{x['nama']} ({x['sheet']} RT{x['rt']}/RW{x['rw']})" for x in v))

print("\njumlah grup:", len(beda))
print("rasio >= 0.75:", sum(1 for r, p, *a in beda if r >= 0.75))
print("prefix / rasio>=0.75:", sum(1 for r, p, *a in beda if p or r >= 0.75))
for t in (0.6, 0.65, 0.7, 0.75, 0.8):
    kabur = [v for r, p, n, v in beda if not p and r < t]
    print(f"  ambang {t}: {sum(len(v)-1 for v in kabur)} baris tetap dipisah ({len(kabur)} grup)")
