import openpyxl, re, collections, unicodedata

SRC = "DAFTAR PEMILIH SEMENTARA (2).xlsx"
REKAP = {"001": 1025, "002": 1291, "003": 798, "004": 1096, "005": 512, "006": 489, "007": 606}
wb = openpyxl.load_workbook(SRC, read_only=True, data_only=True)


def teks(x):
    return re.sub(r"\s+", " ", str(x if x is not None else "").strip()).upper()


def angka(x):
    return re.sub(r"\D", "", str(x if x is not None else ""))


def tiga(x):
    x = angka(x)
    return x.zfill(3) if x else ""


rows = []
for ws in wb.worksheets:
    hdr = None
    for i, r in enumerate(ws.iter_rows(values_only=True), start=1):
        sel = [teks(c) for c in r]
        if "NAMA" in sel and "NIK" in sel:
            hdr = {k: j for j, k in enumerate(sel) if k}
            break
    if not hdr:
        print("skip sheet (tanpa header NAMA/NIK):", ws.title)
        continue
    cocok = re.search(r"RW\.?\s*0*(\d+)", ws.title, re.I)
    rw_sheet = tiga(cocok.group(1)) if cocok else ""
    for r in ws.iter_rows(min_row=i + 1, values_only=True):
        g = lambda k: r[hdr[k]] if k in hdr and hdr[k] < len(r) else None
        nama = teks(g("NAMA"))
        if not nama or nama == "NAMA" or nama.isdigit():
            continue
        rows.append(dict(nama=nama, nik=angka(g("NIK")), kk=angka(g("KK")),
                         rt=tiga(g("RT")), rw=tiga(g("RW")) or rw_sheet,
                         sheet=ws.title, tambahan="TAMBAHAN" in ws.title.upper()))
wb.close()

print("== baris mentah per sheet ==")
per_sheet = collections.Counter(r["sheet"] for r in rows)
for s in ["RW.01", "RW.01TAMBAHAN", "RW.02", "RW.02TAMBAHAN", "RW.03", "RW.03TAMBAHAN",
          "RW.4", "RW.04TAMBAHAN", "RW.5", "RW.05TAMBAHAN", "RW.6", "RW.06TAMBAHAN",
          "RW.07", "RW.07TAMBAHAN"]:
    print(f"  {s:16} {per_sheet[s]:5}")

utama = [r for r in rows if not r["tambahan"]]
print(f"\nbaris SHEET UTAMA (bukan TAMBAHAN): {len(utama)}  | rekap di Sheet1: {sum(REKAP.values())}")
print("per RW utama :", dict(sorted(collections.Counter(r['rw'] for r in utama).items())))
print("rekap Sheet1 :", REKAP)
print(f"baris TAMBAHAN total: {sum(1 for r in rows if r['tambahan'])}")

valid = [r for r in rows if len(r["nik"]) == 16]


def kunci(r):
    if len(r["nik"]) == 16:
        return "nik:" + r["nik"]
    if len(r["kk"]) == 16:
        return "nm:" + r["nama"] + "|" + r["kk"]
    return "nm:" + r["nama"] + "|" + r["rt"] + "|" + r["rw"]


grup = collections.defaultdict(list)
for r in rows:
    grup[kunci(r)].append(r)

dibuang = sum(len(v) - 1 for v in grup.values())
print(f"\ngrup setelah digabung: {len(grup)}  | baris ganda dibuang: {dibuang}")

# kategori duplikat
kategori = collections.Counter()
contoh = collections.defaultdict(list)
for k, v in grup.items():
    if len(v) < 2:
        continue
    sheets = {x["sheet"] for x in v}
    rts = {(x["rw"], x["rt"]) for x in v}
    tamb = any(x["tambahan"] for x in v)
    utama_juga = any(not x["tambahan"] for x in v)
    nama_beda = len({x["nama"] for x in v}) > 1
    if nama_beda:
        kat = "NIK sama tapi NAMA berbeda"
    elif tamh := (tamb and utama_juga):
        kat = "sama di sheet utama + TAMBAHAN"
    elif len(rts) > 1:
        kat = "sama orang, beda RT/beda blok"
    elif tamb:
        kat = "ganda di dalam sheet TAMBAHAN"
    else:
        kat = "ganda di dalam sheet utama"
    kategori[kat] += len(v) - 1
    if len(contoh[kat]) < 4:
        contoh[kat].append(v)

print("\n== kategori baris yang digabung (jumlah baris dibuang) ==")
for k, n in kategori.most_common():
    print(f"  {n:5}  {k}")

for kat, vv in contoh.items():
    print(f"\n  contoh [{kat}]:")
    for v in vv:
        print("   ", " | ".join(f"{x['nama']} ({x['sheet']} RT{x['rt']}/RW{x['rw']} nik…{x['nik'][-4:] or '-'})" for x in v))

# NIK dobel dengan nama berbeda -> kemungkinan salah input NIK, bukan orang yang sama
print("\n== NIK ganda dengan nama berbeda (perlu dicek panitia) ==")
n = 0
for k, v in grup.items():
    if len(v) > 1 and len({x["nama"] for x in v}) > 1:
        n += 1
        if n <= 10:
            print("  NIK", v[0]["nik"], "->", " | ".join(f"{x['nama']} ({x['sheet']} RT{x['rt']})" for x in v))
print("  total grup:", n)

# per RW hasil akhir
akhir = collections.Counter()
for v in grup.values():
    r = sorted(v, key=lambda x: (x["tambahan"], not x["kk"]))[0]
    akhir[r["rw"]] += 1
print("\n== perbandingan per RW ==")
print(f"  {'RW':4} {'rekap':>6} {'unik':>6} {'selisih':>8}")
for rw in sorted(REKAP):
    print(f"  {rw:4} {REKAP[rw]:6} {akhir.get(rw,0):6} {REKAP[rw]-akhir.get(rw,0):8}")
print(f"  {'ALL':4} {sum(REKAP.values()):6} {sum(akhir.values()):6} {sum(REKAP.values())-sum(akhir.values()):8}")
print("  unik per RW:", dict(sorted(akhir.items())))
